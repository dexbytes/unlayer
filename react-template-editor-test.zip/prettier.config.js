module.exports = {
  singleQuote: true,
  arrowParens: 'always',
  trailingComma: 'es5',
};
